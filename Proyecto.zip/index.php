<?php session_start(); ?>
<link rel="stylesheet" href="/assets/css/dark.css">
<div class="container">
<h1>Sistema de Repuestos de Motos</h1>
<a href='auth/login.php'>Login</a> |
<a href='auth/register.php'>Registro</a> |
<a href='pedidos/formulario.php'>Solicitar repuesto</a> |
<a href='inventario/catalogo.php'>Comprar repuestos</a>

<a href='admin/admin_login.php' style='position:fixed;bottom:10px;right:10px;'>Admin</a>
</div>
